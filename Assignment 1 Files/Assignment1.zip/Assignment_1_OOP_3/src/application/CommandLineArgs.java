package application;

public class CommandLineArgs {
	private static final String COMPARE_TYPES = "oud";
    private static final String SORT_TYPES = "bsimqz";

    public static final String USAGE =
        "Usage: java -jar Sort.jar -f<file_name> -t<compare_type> -s<sort_alg>\n"
        + "  -f  file name and path, e.g. -fres\\products1.txt\n"
        + "  -t  compare type: o (original price), u (updated price), d (real difference)\n"
        + "  -s  sort algorithm: b (bubble), s (selection), i (insertion), m (merge), q (quick), z (your choice)\n"
        + "Flags are case insensitive, can be in any order, and must have no space before the value.\n"
        + "Example: java -jar Sort.jar -fproducts1.txt -To -Sb";

    private String fileName;
    private char compareType;
    private char sortType;

    private CommandLineArgs() { }

    public String getFileName()  { return fileName; }
    public char getCompareType() { return compareType; }
    public char getSortType()    { return sortType; }

    /**
     * @throws IllegalArgumentException with a user friendly message if args are invalid
     */
    public static CommandLineArgs parse(String[] args)
    {
        CommandLineArgs result = new CommandLineArgs();

        if (args == null || args.length == 0)
        {
            throw new IllegalArgumentException("No arguments provided.\n" + USAGE);
        }

        boolean hasF = false, hasT = false, hasS = false;

        for (String raw : args)
        {
            // Normalize en/em dashes (copy-pasted from Word/PDF) to a plain hyphen
            String arg = raw.trim().replace('\u2013', '-').replace('\u2014', '-');

            if (arg.length() < 2 || arg.charAt(0) != '-')
            {
                throw new IllegalArgumentException(
                    "Invalid argument \"" + raw + "\": arguments must start with -f, -t or -s.\n" + USAGE);
            }

            char flag = Character.toLowerCase(arg.charAt(1));
            String value = arg.substring(2).trim();

            // Strip surrounding quotes if the shell left them in
            if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\""))
            {
                value = value.substring(1, value.length() - 1);
            }

            switch (flag)
            {
                case 'f':
                    if (hasF) throw duplicate("-f");
                    if (value.isEmpty())
                    {
                        throw new IllegalArgumentException(
                            "Missing file name after -f. Example: -fproducts1.txt\n" + USAGE);
                    }
                    result.fileName = value;
                    hasF = true;
                    break;

                case 't':
                    if (hasT) throw duplicate("-t");
                    result.compareType = parseChoice(value, COMPARE_TYPES, "-t",
                        "o (original price), u (updated price) or d (real difference)");
                    hasT = true;
                    break;

                case 's':
                    if (hasS) throw duplicate("-s");
                    result.sortType = parseChoice(value, SORT_TYPES, "-s",
                        "b (bubble), s (selection), i (insertion), m (merge), q (quick) or z (your choice)");
                    hasS = true;
                    break;

                default:
                    throw new IllegalArgumentException(
                        "Unknown option \"" + raw + "\". Valid options are -f, -t and -s.\n" + USAGE);
            }
        }

        if (!hasF) throw new IllegalArgumentException("Missing required option -f<file_name>.\n" + USAGE);
        if (!hasT) throw new IllegalArgumentException("Missing required option -t<compare_type>.\n" + USAGE);
        if (!hasS) throw new IllegalArgumentException("Missing required option -s<sort_alg>.\n" + USAGE);

        return result;
    }

    private static char parseChoice(String value, String allowed, String flag, String description)
    {
        if (value.length() != 1 || allowed.indexOf(Character.toLowerCase(value.charAt(0))) < 0)
        {
            throw new IllegalArgumentException(
                "Invalid value \"" + value + "\" for " + flag + ". Expected " + description + ".\n" + USAGE);
        }
        return Character.toLowerCase(value.charAt(0));
    }

    private static IllegalArgumentException duplicate(String flag)
    {
        return new IllegalArgumentException("Option " + flag + " was provided more than once.\n" + USAGE);
    }
}


