package application;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Comparator;

import appDomain.Product;
import external.OriginalPriceComparator;
import external.UpdatedPriceComparator;
import utilities.BubbleSort;
import utilities.HeapSort;
import utilities.InsertionSort;
import utilities.MergeSort;
import utilities.ProductFileReader;
import utilities.QuickSort;
import utilities.SelectionSort;

public final class SortApplication {

	private SortApplication() {
	}

	// Loads products, sorts them, and displays the timing and selected results
	public static void run(String[] args) throws IOException {
		Options options = Options.parse(args);
		Product[] products = ProductFileReader.read(options.file);
		Comparator<Product> compareType = getComparator(options.compareType);
		Comparator<Product> descendingOrder = compareType.reversed();

		// Measure only the selected sorting algorithm
		long startTime = System.nanoTime();
		sortProducts(products, descendingOrder, options.sortType);
		long elapsedTime = System.nanoTime() - startTime;

		System.out.printf(java.util.Locale.ROOT,
				"Sorting algorithm: %s%nCompare type: %s%nSort time: %.3f ms%n",
				getSortName(options.sortType), getCompareName(options.compareType), elapsedTime / 1_000_000.0);
		printProducts(products);
	}

	// Selects the required comparison rule
	private static Comparator<Product> getComparator(char compareType) {
		if (compareType == 'o') {
			return new OriginalPriceComparator();
		} else if (compareType == 'u') {
			return new UpdatedPriceComparator();
		}
		return Comparator.naturalOrder();
	}

	// Selects and runs the requested sorting algorithm
	private static void sortProducts(Product[] products, Comparator<Product> order, char sortType) {
		switch (sortType) {
		case 'b':
			BubbleSort.bubbleSort(products, order);
			break;
		case 's':
			SelectionSort.selectionSort(products, order);
			break;
		case 'i':
			InsertionSort.insertionSort(products, order);
			break;
		case 'm':
			MergeSort.mergeSort(products, order);
			break;
		case 'q':
			QuickSort.quickSort(products, order);
			break;
		case 'z':
			HeapSort.heapSort(products, order);
			break;
		default:
			throw new IllegalArgumentException("Unknown sorting algorithm.");
		}
	}

	// Prints all records for small files and samples larger sorted arrays
	private static void printProducts(Product[] products) {
		System.out.println("Sorted products:");
		if (products.length <= 10) {
			for (Product product : products) {
				System.out.println(product);
			}
			return;
		}

		int interval = products.length <= 1000 ? 100 : 1000;
		int last = products.length - 1;
		System.out.println("1: " + products[0]);
		for (int index = interval - 1; index < last; index += interval) {
			System.out.println((index + 1) + ": " + products[index]);
		}
		System.out.println((last + 1) + ": " + products[last]);
	}

	private static String getSortName(char sortType) {
		switch (sortType) {
		case 'b':
			return "Bubble sort";
		case 's':
			return "Selection sort";
		case 'i':
			return "Insertion sort";
		case 'm':
			return "Merge sort";
		case 'q':
			return "Quicksort (median of three)";
		default:
			return "Heapsort";
		}
	}

	private static String getCompareName(char compareType) {
		if (compareType == 'o') {
			return "original price";
		} else if (compareType == 'u') {
			return "updated price";
		}
		return "calculated difference";
	}

	// Stores and validates the command-line options
	private static class Options {
		private Path file;
		private char compareType;
		private char sortType;

		private static Options parse(String[] args) {
			Options options = new Options();
			boolean fileProvided = false;
			boolean compareProvided = false;
			boolean sortProvided = false;

			for (int i = 0; i < args.length; i++) {
				String argument = args[i];
				if (argument == null || argument.length() < 2 || argument.charAt(0) != '-') {
					throw usageError();
				}
				char flag = Character.toLowerCase(argument.charAt(1));
				String value = argument.substring(2);
				if (value.startsWith("=")) {
					value = value.substring(1);
				}
				if (value.isEmpty() && i + 1 < args.length) {
					value = args[++i];
				}
				if (value == null || value.isEmpty()) {
					throw usageError();
				}
				if (value.length() >= 2 && ((value.startsWith("\"") && value.endsWith("\""))
						|| (value.startsWith("'") && value.endsWith("'")))) {
					value = value.substring(1, value.length() - 1);
				}

				if (flag == 'f') {
					if (fileProvided || value.trim().isEmpty()) {
						throw usageError();
					}
					options.file = Path.of(value);
					fileProvided = true;
			} else if (flag == 't') {
					if (compareProvided || value.length() != 1) {
						throw usageError();
					}
					options.compareType = Character.toLowerCase(value.charAt(0));
					if ("oud".indexOf(options.compareType) < 0) {
						throw usageError();
					}
					compareProvided = true;
			} else if (flag == 's') {
					if (sortProvided || value.length() != 1) {
						throw usageError();
					}
					options.sortType = Character.toLowerCase(value.charAt(0));
					if ("bsimqz".indexOf(options.sortType) < 0) {
						throw usageError();
					}
					sortProvided = true;
				} else {
					throw usageError();
				}
			}

			if (!fileProvided || !compareProvided || !sortProvided) {
				throw usageError();
			}
			return options;
		}

		private static IllegalArgumentException usageError() {
			return new IllegalArgumentException("Usage: java -jar Sort.jar -f<file> -t<o|u|d> -s<b|s|i|m|q|z>\n"
					+ "Options may be attached or separated and may appear in any order.\n"
					+ "Example: java -jar Sort.jar -fres/products1.txt -td -sm\n"
					+ "Or: java -jar Sort.jar -f res/products1.txt -t d -s m");
		}
	}
}
