package external;

import java.util.Comparator;

import appDomain.Product;

// Comparator for original product price
public class OriginalPriceComparator implements Comparator<Product> {

	@Override
	public int compare(Product first, Product second) {
		return Double.compare(first.getOriginalPrice(), second.getOriginalPrice());
	}
}
