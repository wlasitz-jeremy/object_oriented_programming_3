package external;

import java.util.Comparator;

import problemDomain.Product;

// Comparator for updated product price
public class UpdatedPriceComparator implements Comparator<Product>{
	// Compares two Product objects based on their updated price in ascending order.
	@Override
	public int compare(Product p1, Product p2) {
		return Double.compare(p1.getUpdatedPrice(), p2.getUpdatedPrice());
	}

}
