package external;

import java.util.Comparator;

import appDomain.Product;

// Comparator for updated product price
public class UpdatedPriceComparator implements Comparator<Product> {

	@Override
	public int compare(Product first, Product second) {
		return Double.compare(first.getUpdatedPrice(), second.getUpdatedPrice());
	}
}
