package external;

import java.util.Comparator;
import problemDomain.Product;
// Comparator for sorting products based on the real difference between original and updated prices.
public class RealDifferenceComparator implements Comparator<Product> {
	// Compare two products based on the real difference between their original and updated prices.
    @Override
    public int compare(Product p1, Product p2) {
        return Double.compare(p1.calcRealDiff(), p2.calcRealDiff());
    }
}