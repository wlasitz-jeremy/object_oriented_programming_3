package utilities;

import java.util.Comparator;

import appDomain.Product;

public class MergeSort {

	// Recursively divides the array, sorts each half, and merges the results
	// Runtime: O(n log n); extra space: O(n)
	public static void mergeSort(Product[] products, Comparator<Product> comparator) {
		if (products.length <= 1) {
			return;
		}

		int middle = products.length / 2;
		Product[] left = new Product[middle];
		Product[] right = new Product[products.length - middle];

		for (int i = 0; i < products.length; i++) {
			if (i < middle) {
				left[i] = products[i];
			} else {
				right[i - middle] = products[i];
			}
		}

		mergeSort(left, comparator);
		mergeSort(right, comparator);
		merge(left, right, products, comparator);
	}

	// Combines two sorted arrays into the original array
	private static void merge(Product[] left, Product[] right, Product[] products,
			Comparator<Product> comparator) {
		int leftIndex = 0;
		int rightIndex = 0;
		int outputIndex = 0;

		while (leftIndex < left.length && rightIndex < right.length) {
			if (comparator.compare(left[leftIndex], right[rightIndex]) <= 0) {
				products[outputIndex++] = left[leftIndex++];
			} else {
				products[outputIndex++] = right[rightIndex++];
			}
		}
		while (leftIndex < left.length) {
			products[outputIndex++] = left[leftIndex++];
		}
		while (rightIndex < right.length) {
			products[outputIndex++] = right[rightIndex++];
		}
	}
}
