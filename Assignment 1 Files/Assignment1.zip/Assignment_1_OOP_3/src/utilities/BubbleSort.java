package utilities;

import java.util.Comparator;

import appDomain.Product;

public class BubbleSort {

	// Repeatedly compares adjacent products and swaps them when they are out of order
	// Runtime: O(n^2); extra space: O(1)
	public static void bubbleSort(Product[] products, Comparator<Product> comparator) {
		for (int end = products.length - 1; end > 0; end--) {
			for (int i = 0; i < end; i++) {
				if (comparator.compare(products[i], products[i + 1]) > 0) {
					Product temp = products[i];
					products[i] = products[i + 1];
					products[i + 1] = temp;
				}
			}
		}
	}
}
