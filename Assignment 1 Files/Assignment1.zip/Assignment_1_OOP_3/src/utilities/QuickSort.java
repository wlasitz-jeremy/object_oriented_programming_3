package utilities;

import java.util.Comparator;

import appDomain.Product;

public class QuickSort {

	// Sorts the products using a median-of-three pivot
	// Best and average runtime: O(n log n); worst runtime: O(n^2)
	public static void quickSort(Product[] products, Comparator<Product> comparator) {
		quick_sort(products, 0, products.length - 1, comparator);
	}

	private static void quick_sort(Product[] products, int start, int end, Comparator<Product> comparator) {
		if (start >= end) {
			return;
		}

		Product pivot = getMedian(products[start], products[start + (end - start) / 2], products[end], comparator);
		int left = start;
		int right = end;

		// Moves products smaller than the pivot left and larger products right
		while (left <= right) {
			while (comparator.compare(products[left], pivot) < 0) {
				left++;
			}
			while (comparator.compare(products[right], pivot) > 0) {
				right--;
			}
			if (left <= right) {
				swap(products, left, right);
				left++;
				right--;
			}
		}

		if (start < right) {
			quick_sort(products, start, right, comparator);
		}
		if (left < end) {
			quick_sort(products, left, end, comparator);
		}
	}

	// Returns the median product from the first, middle, and last positions
	private static Product getMedian(Product first, Product middle, Product last,
			Comparator<Product> comparator) {
		if (comparator.compare(first, middle) < 0) {
			if (comparator.compare(middle, last) < 0) {
				return middle;
			}
			return comparator.compare(first, last) < 0 ? last : first;
		}
		if (comparator.compare(first, last) < 0) {
			return first;
		}
		return comparator.compare(middle, last) < 0 ? last : middle;
	}

	private static void swap(Product[] products, int first, int second) {
		Product temp = products[first];
		products[first] = products[second];
		products[second] = temp;
	}
}
