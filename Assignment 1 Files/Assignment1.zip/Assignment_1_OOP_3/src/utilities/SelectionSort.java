package utilities;

import java.util.Comparator;

import appDomain.Product;

public class SelectionSort {

	// Finds the next product in order and places it in the sorted section
	// Runtime: O(n^2); extra space: O(1)
	public static void selectionSort(Product[] products, Comparator<Product> comparator) {
		for (int start = 0; start < products.length - 1; start++) {
			int first = start;
			for (int i = start + 1; i < products.length; i++) {
				if (comparator.compare(products[i], products[first]) < 0) {
					first = i;
				}
			}
			Product temp = products[start];
			products[start] = products[first];
			products[first] = temp;
		}
	}
}
