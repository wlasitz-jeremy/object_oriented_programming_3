package utilities;

import java.util.Comparator;

import appDomain.Product;

public class HeapSort {

	// Builds a heap and repeatedly moves its root to the end of the unsorted range
	// Runtime: O(n log n); extra space: O(1)
	public static void heapSort(Product[] products, Comparator<Product> comparator) {
		for (int root = products.length / 2 - 1; root >= 0; root--) {
			siftDown(products, root, products.length, comparator);
		}
		for (int end = products.length - 1; end > 0; end--) {
			Product temp = products[0];
			products[0] = products[end];
			products[end] = temp;
			siftDown(products, 0, end, comparator);
		}
	}

	private static void siftDown(Product[] products, int root, int size, Comparator<Product> comparator) {
		while (root * 2 + 1 < size) {
			int child = root * 2 + 1;
			if (child + 1 < size && comparator.compare(products[child], products[child + 1]) < 0) {
				child++;
			}
			if (comparator.compare(products[root], products[child]) >= 0) {
				return;
			}
			Product temp = products[root];
			products[root] = products[child];
			products[child] = temp;
			root = child;
		}
	}
}
