package utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import appDomain.Dresses;
import appDomain.Jackets;
import appDomain.Jeans;
import appDomain.Product;
import appDomain.Shoes;
import appDomain.Shorts;
import appDomain.Skirts;
import appDomain.TShirts;

public final class ProductFileReader {

	private ProductFileReader() {
	}

	// Reads the file count and creates the product array
	public static Product[] read(Path path) throws IOException {
		try (BufferedReader reader = Files.newBufferedReader(path)) {
			String firstLine = reader.readLine();
			if (firstLine == null) {
				throw new IOException("The product file is empty.");
			}

			int count;
			try {
				count = Integer.parseInt(firstLine.trim());
			} catch (NumberFormatException e) {
				throw new IOException("The first line must be the number of products.", e);
			}
			if (count < 0) {
				throw new IOException("The product count cannot be negative.");
			}

			Product[] products = new Product[count];
			for (int i = 0; i < count; i++) {
				String line = reader.readLine();
				if (line == null) {
					throw new IOException("Expected " + count + " products, but found " + i + ".");
				}
				String[] fields = line.trim().split("\\s+");
				if (fields.length != 3) {
					throw new IOException("Invalid product data at line " + (i + 2) + ".");
				}

				try {
					double originalPrice = Double.parseDouble(fields[1]);
					double updatedPrice = Double.parseDouble(fields[2]);
					products[i] = createProduct(fields[0], originalPrice, updatedPrice);
				} catch (IllegalArgumentException e) {
					throw new IOException("Invalid product data at line " + (i + 2) + ": " + e.getMessage(), e);
				}
			}

			if (reader.readLine() != null) {
				throw new IOException("The file contains more products than its header specifies.");
			}
			return products;
		}
	}

	// Creates the matching product subclass for a data file row
	private static Product createProduct(String type, double originalPrice, double updatedPrice) throws IOException {
		switch (type) {
		case "Jeans":
			return new Jeans(originalPrice, updatedPrice);
		case "TShirts":
			return new TShirts(originalPrice, updatedPrice);
		case "Skirts":
			return new Skirts(originalPrice, updatedPrice);
		case "Dresses":
			return new Dresses(originalPrice, updatedPrice);
		case "Shorts":
			return new Shorts(originalPrice, updatedPrice);
		case "Jackets":
			return new Jackets(originalPrice, updatedPrice);
		case "Shoes":
			return new Shoes(originalPrice, updatedPrice);
		default:
			throw new IOException("Unknown product type '" + type + "'.");
		}
	}
}
