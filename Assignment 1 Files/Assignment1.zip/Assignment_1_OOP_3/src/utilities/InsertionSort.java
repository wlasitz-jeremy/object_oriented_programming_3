package utilities;

import java.util.Comparator;

import appDomain.Product;

public class InsertionSort {

	// Inserts each product into its position in the sorted section
	// Runtime: best O(n), average and worst O(n^2); extra space: O(1)
	public static void insertionSort(Product[] products, Comparator<Product> comparator) {
		for (int i = 1; i < products.length; i++) {
			Product c = products[i];
			int j = i - 1;
			while (j >= 0 && comparator.compare(products[j], c) > 0) {
				products[j + 1] = products[j];
				j--;
			}
			products[j + 1] = c;
		}
	}
}
