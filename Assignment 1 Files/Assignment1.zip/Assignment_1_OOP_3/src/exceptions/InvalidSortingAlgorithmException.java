package exceptions;
// Thrown when an invalid sorting algorithm is specified.
public class InvalidSortingAlgorithmException extends Exception {
	/**
	 * 
	 */
	// Unique identifier for serialization.
	private static final long serialVersionUID = -4463904926282921531L;

	// Constructor that accepts a message describing the exception.
	public InvalidSortingAlgorithmException(String message) {
		super(message);
	}

}
