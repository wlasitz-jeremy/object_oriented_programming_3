package exceptions;

@SuppressWarnings("serial")
public class InvalidPriceException extends Exception {
	
	public InvalidPriceException(String message) {
		super ("Invalid Argument:" + message + ". Please enter: o, u or d.");
	}

}
