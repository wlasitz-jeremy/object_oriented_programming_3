package exceptions;

@SuppressWarnings("serial")
public class InvalidSortException extends Exception{
	
	public InvalidSortException(String message) {
		super ("Invalid Argument:" + message + ". Please enter: b, s, i, m, q or z.");
	}

}
