package exceptions;

@SuppressWarnings("serial")
public class InvalidFileNameException extends Exception {
	
	public InvalidFileNameException(String message) {
		super ("Invalid Argument:" + message + ". Please enter proper file name.");
	}

}
