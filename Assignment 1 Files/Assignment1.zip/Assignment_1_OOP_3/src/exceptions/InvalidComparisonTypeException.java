package exceptions;
// Thrown when an invalid comparison type is specified.
public class InvalidComparisonTypeException extends Exception {
	/**
	 * 
	 */
	// Unique identifier for serialization.
	private static final long serialVersionUID = -4484996527520614932L;

	// Constructor that accepts a message describing the exception.
	public InvalidComparisonTypeException(String message) {
		super(message);
	}

}
