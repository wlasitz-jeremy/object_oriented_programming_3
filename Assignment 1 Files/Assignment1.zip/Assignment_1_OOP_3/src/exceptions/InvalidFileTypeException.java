package exceptions;
// Thrown when an invalid file type is encountered.
public class InvalidFileTypeException extends Exception {
	/**
	 * 
	 */
	// Unique identifier for serialization.
	private static final long serialVersionUID = -3123023625228523113L;

	// Constructor that accepts a message describing the exception.
	public InvalidFileTypeException() {
		super("Invalid file type, please provide a valid one.");
	}

}
