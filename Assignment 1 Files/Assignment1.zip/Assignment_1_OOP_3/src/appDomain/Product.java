package appDomain;

import java.util.Objects;

public abstract class Product implements Comparable<Product> {

	// Product price attributes
	private final double originalPrice;
	private final double updatedPrice;

	// Parameterized constructor
	protected Product(double originalPrice, double updatedPrice) {
		if (!Double.isFinite(originalPrice) || !Double.isFinite(updatedPrice)) {
			throw new IllegalArgumentException("Prices must be finite numbers.");
		}
		this.originalPrice = originalPrice;
		this.updatedPrice = updatedPrice;
	}

	// Getters
	public final double getOriginalPrice() {
		return originalPrice;
	}

	public final double getUpdatedPrice() {
		return updatedPrice;
	}

	// Product-specific methods
	public abstract double calcRealDiff();

	public abstract String getType();

	// Natural ordering uses the calculated difference
	@Override
	public final int compareTo(Product other) {
		Objects.requireNonNull(other, "other");
		return Double.compare(calcRealDiff(), other.calcRealDiff());
	}

	// Formats product details for display
	@Override
	public final String toString() {
		return String.format(java.util.Locale.ROOT, "%s original=%.2f updated=%.2f realDiff=%s",
				getType(), originalPrice, updatedPrice, Double.toString(calcRealDiff()));
	}
}
