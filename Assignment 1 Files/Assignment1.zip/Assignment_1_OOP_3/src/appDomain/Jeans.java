package appDomain;

public final class Jeans extends Product {

	// Creates a jeans product
	public Jeans(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for jeans
	@Override
	public double calcRealDiff() {
		return 0.5 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Jeans";
	}
}
