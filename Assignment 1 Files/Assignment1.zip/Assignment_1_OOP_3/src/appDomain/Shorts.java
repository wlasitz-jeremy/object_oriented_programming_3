package appDomain;

public final class Shorts extends Product {

	// Creates a shorts product
	public Shorts(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for shorts
	@Override
	public double calcRealDiff() {
		return 0.3 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Shorts";
	}
}
