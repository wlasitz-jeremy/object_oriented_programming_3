package appDomain;

public final class Skirts extends Product {

	// Creates a skirt product
	public Skirts(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for skirts
	@Override
	public double calcRealDiff() {
		return 0.1 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Skirts";
	}
}
