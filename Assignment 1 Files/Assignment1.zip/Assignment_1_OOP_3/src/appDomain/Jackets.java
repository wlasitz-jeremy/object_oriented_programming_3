package appDomain;

public final class Jackets extends Product {

	// Creates a jacket product
	public Jackets(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for jackets
	@Override
	public double calcRealDiff() {
		return 0.7 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Jackets";
	}
}
