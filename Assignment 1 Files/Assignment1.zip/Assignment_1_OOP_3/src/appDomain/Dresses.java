package appDomain;

public final class Dresses extends Product {

	// Creates a dress product
	public Dresses(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for dresses
	@Override
	public double calcRealDiff() {
		return 0.6 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Dresses";
	}
}
