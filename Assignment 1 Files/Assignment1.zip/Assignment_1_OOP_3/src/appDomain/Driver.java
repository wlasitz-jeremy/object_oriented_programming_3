package appDomain;

import java.io.IOException;

import application.SortApplication;

public class Driver {

	public static void main(String[] args) {
		try {
			SortApplication.run(args);
		} catch (IOException | IllegalArgumentException e) {
			System.err.println("Unable to run sorting application: " + e.getMessage());
			System.exit(1);
		}
	}
}
