package appDomain;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import application.CommandLineArgs;
import application.SortingApplication;
import exceptions.InvalidComparisonTypeException;
import exceptions.InvalidFileTypeException;
import exceptions.InvalidSortingAlgorithmException;
import problemDomain.Product;

public class Driver {

	public static void main(String[] args) throws FileNotFoundException, IOException, InvalidFileTypeException,
			InvalidSortingAlgorithmException, InvalidComparisonTypeException {
		CommandLineArgs options;

		try {
			options = CommandLineArgs.parse(args);
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			return;
		}

		File file = new File(options.getFileName());

		try {
			if (!file.exists()) {
				throw new FileNotFoundException();
			}
		} catch (FileNotFoundException e) {
			System.out.println("Cannot find the file \"" + options.getFileName() + "\". Check the file name and path.");
			return;
		}

		Product[] products = SortingApplication.run(options);
		if (products == null) {
			return;
		}

		printProducts(products, options.getCompareType());
	}

	private static void printProducts(Product[] products, char compareType) {
		if (products.length == 0) {
			System.out.println("No products to display.");
			return;
		}

		if (products.length <= 10) {
			for (int i = 0; i < products.length; i++) {
				printProduct(products[i], compareType, ordinalLabel(i + 1));
			}
			return;
		}

		int interval = products.length <= 1000 ? 100 : 1000;
		printProduct(products[0], compareType, "First element is:");
		for (int i = interval - 1; i < products.length - 1; i += interval) {
			printProduct(products[i], compareType, ordinalLabel(i + 1));
		}
		if (products.length > 1) {
			printProduct(products[products.length - 1], compareType, "Last element is:");
		}
	}

	private static String ordinalLabel(int itemNumber) {
		String suffix = itemNumber == 1 ? "st" : itemNumber == 2 ? "nd" : itemNumber == 3 ? "rd" : "th";
		return itemNumber + "-" + suffix + " element:";
	}

	private static void printProduct(Product product, char compareType, String positionLabel) {
		String label;
		double value;
		switch (compareType) {
		case 'o':
			label = "Original Price";
			value = product.getOriginalPrice();
			break;
		case 'u':
			label = "Updated Price";
			value = product.getUpdatedPrice();
			break;
		case 'd':
			label = "Real Difference";
			value = product.calcRealDiff();
			break;
		default:
			return;
		}
		System.out.printf("%-22s products.%-12s %s: %s%n", positionLabel, product.getProdType(), label,
				compareType == 'd' ? Double.toString(value) : String.format("%.2f", value));
	}

}
