package appDomain;

public final class Shoes extends Product {

	// Creates a shoes product
	public Shoes(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the adjusted price difference for shoes
	@Override
	public double calcRealDiff() {
		return 0.4 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}

	@Override
	public String getType() {
		return "Shoes";
	}
}
