package manager;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import problemDomain.*;

public class ProductReader {

	public static Product[] ReadProductOne(String filepath) throws FileNotFoundException, IOException {
		try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
			int numberOfProducts = Integer.parseInt(reader.readLine().trim());
			Product[] products = new Product[numberOfProducts];
			for (int i = 0; i < numberOfProducts; i++) {
				String line = reader.readLine();
				String[] fields = line.trim().split(" ");
				String name = fields[0];
				double originalPrice = Double.parseDouble(fields[1]);
				double updatedPrice = Double.parseDouble(fields[2]);

				switch (name) {
				case "Dresses":
					products[i] = new Dresses(originalPrice, updatedPrice);
					break;
				case "Jackets":
					products[i] = new Jackets(originalPrice, updatedPrice);
					break;
				case "Jeans":
					products[i] = new Jeans(originalPrice, updatedPrice);
					break;
				case "Shoes":
					products[i] = new Shoes(originalPrice, updatedPrice);
					break;
				case "Shorts":
					products[i] = new Shorts(originalPrice, updatedPrice);
					break;
				case "Skirts":
					products[i] = new Skirts(originalPrice, updatedPrice);
					break;
				case "TShirts":
					products[i] = new TShirts(originalPrice, updatedPrice);
					break;
				default:
					throw new FileNotFoundException("File not found");
				}

			}
			return products;
		}

	}
}
