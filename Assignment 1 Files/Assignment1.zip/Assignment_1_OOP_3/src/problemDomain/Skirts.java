package problemDomain;

public final class Skirts extends Product{
	// Constructor for the Skirts class that initializes the original and updated prices by calling the superclass constructor.
	public Skirts(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for skirts, which is 10% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.1 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "Skirts" for this class.
	@Override
	public String getProdType() {
		return "Skirts";
	}

}
