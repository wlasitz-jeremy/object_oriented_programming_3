package problemDomain;

public final class Shoes extends Product{
	// Constructor for the Shoes class that initializes the original and updated prices by calling the superclass constructor.
	public Shoes(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for Shoes, which is 40% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.4 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "Shoes" for this class.
	@Override
	public String getProdType() {
		return "Shoes";
	}

}
