package problemDomain;

public final class TShirts extends Product{
	// Constructor for TShirts class that initializes the original and updated prices using the superclass constructor.
	public TShirts(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}

	// Calculates the real difference in price for TShirts, which is 20% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.2 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "TShirts" for this class.
	@Override
	public String getProdType() {
		return "TShirts";
	}

}
