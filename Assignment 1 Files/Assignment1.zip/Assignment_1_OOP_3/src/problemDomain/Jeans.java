package problemDomain;

public final class Jeans extends Product{
	// Constructor for the Jeans class that initializes the original and updated prices of the product.
	public Jeans(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for Jeans, which is half the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.5 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "Jeans" for this class.
	@Override
	public String getProdType() {
		return "Jeans";
	}

}
