package problemDomain;

public final class Dresses extends Product{
	// Constructor for the Dresses class that initializes the original and updated prices of the product.
	public Dresses(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for Dresses, which is 60% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.6 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "Dresses" for this class.
	@Override
	public String getProdType() {
		return "Dresses";
	}

}
