package problemDomain;

public final class Shorts extends Product{
	// Constructor for the Shorts class that initializes the original and updated prices.
	public Shorts(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for Shorts, which is 30% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.3 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as "Shorts".
	@Override
	public String getProdType() {
		return "Shorts";
	}

}
