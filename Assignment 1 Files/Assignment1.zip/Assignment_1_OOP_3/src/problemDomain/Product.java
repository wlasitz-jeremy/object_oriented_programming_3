package problemDomain;

public abstract class Product implements Comparable<Product>{
	
	// Product price attributes
	private final double originalPrice;
	private final double updatedPrice;
	
	// Parameterized Constructor
	public Product(double originalPrice, double updatedPrice) {
		this.originalPrice = originalPrice;
		this.updatedPrice = updatedPrice;
	}

	// Getters and Setters
	public final double getOriginalPrice() {
		return originalPrice;
	}
	public final double getUpdatedPrice() {
		return updatedPrice;
	}
	
	// Product Specific abstract methods to be implemented for all product types
	public abstract double calcRealDiff();
	public abstract String getProdType();
	
	// Natural ordering uses the calculated difference
	@Override
	public final int compareTo(Product other) {
		return Double.compare(calcRealDiff(), other.calcRealDiff());
	}
	// Override toString method to provide a string representation of the Product object
	@Override
	public String toString() {
		return "Product [originalPrice=" + originalPrice + ", updatedPrice=" + updatedPrice + ", getOriginalPrice()="
				+ getOriginalPrice() + ", getUpdatedPrice()=" + getUpdatedPrice() + ", calcRealDiff()=" + calcRealDiff()
				+ ", getProdType()=" + getProdType() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
}
