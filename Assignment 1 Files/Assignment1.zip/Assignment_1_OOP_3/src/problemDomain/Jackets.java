package problemDomain;

public final class Jackets extends Product{
	// Constructor for the Jackets class that initializes the original and updated prices by calling the superclass constructor.
	public Jackets(double originalPrice, double updatedPrice) {
		super(originalPrice, updatedPrice);
	}
	// Calculates the real difference in price for jackets, which is 70% of the absolute difference between the original and updated prices.
	@Override
	public double calcRealDiff() {
		return 0.7 * Math.abs(getOriginalPrice() - getUpdatedPrice());
	}
	// Returns the product type as a string, which is "Jackets" for this class.
	@Override
	public String getProdType() {
		return "Jackets";
	}

}
