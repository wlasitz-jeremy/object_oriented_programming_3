module Assignment_1_OOP_3 {
	exports appDomain;
	exports application;
	exports external;
	exports utilities;
}
